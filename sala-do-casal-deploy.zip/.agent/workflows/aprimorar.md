---
description: Estuda uma referência de mundo aberto e melhora UMA coisa no jogo a partir dela
---

# /aprimorar — uma melhoria por vez, com referência

Esta automação **não** é para consertar bugs (isso é `/revisar`). É para o jogo ir ficando
melhor de jogar, aprendendo com jogos de mundo aberto que já acertaram.

> ⚠️ **Uma melhoria por rodada.** Não dez. Uma, bem feita, verificada e registrada.
> Dez mudanças ao mesmo tempo é o jeito mais rápido de estragar um jogo que funciona.

Antes de começar, leia `docs/DIARIO.md` para não repetir uma rodada anterior.

---

## 1. Escolher o que estudar

Abra `docs/REFERENCIAS.md`. Escolha **um** item ainda não marcado como estudado,
de preferência o que resolve a dor mais visível do jogo hoje.

Se nenhum item cobre o problema que você está vendo, pesquise na web
("open world game design <assunto>", "<jogo> level design analysis") e **acrescente** o item
novo ao `docs/REFERENCIAS.md` antes de continuar.

## 2. Estudar de verdade

Leia/assista e extraia **o princípio**, não o detalhe decorativo. A pergunta certa é
*"por que isso funciona?"*, não *"como era a cor do ícone?"*.

Escreva em 3 a 5 linhas:
- **O princípio:** o que aquele jogo fez
- **Por que funciona:** o efeito na pessoa que joga
- **Como se aplica aqui:** num jogo pequeno, de navegador, para duas pessoas

Se não consegue escrever a terceira linha, a referência não serve agora. Escolha outra.

## 3. Propor antes de fazer

Antes de escrever código, diga em até 5 linhas:
- a mudança
- em quais arquivos (`world3d.js`? `main.js`? `index.html` + `style.css`?)
- como vai dar para ver que ficou melhor
- o que **não** vai mudar

Se a mudança for grande (refaz o mundo, muda o controle, troca o HUD inteiro, mexe na rede),
**pare e pergunte.**

## 4. Fazer e medir

1. Implemente a mudança mínima.
2. Abra o jogo, faça a ação, **tire print antes e depois** se for visual.
3. **Meça o custo:** FPS e draw calls antes e depois (`renderer.info.render.calls`).
   Os limites estão em `AGENTS.md`.
4. Teste no celular também (janela 390x844).
5. Confira que os 9 minigames continuam entrando e terminando.
6. Se custou desempenho e não compensou, **volte atrás.** Voltar atrás é resultado válido.

## 5. Registrar

Em `docs/REFERENCIAS.md`, marque o item estudado e anote em uma linha o que saiu dele.

Em `docs/DIARIO.md`, acrescente no topo:

```markdown
## <data> — aprimoramento
**Referência:** <jogo / artigo>
**Princípio:** <uma linha>
**O que mudei:** <uma linha, com os arquivos>
**Ficou melhor porque:** <o que você observou, não o que você espera>
**Custo:** FPS __ → __ · draw calls __ → __
```

Responda em até 8 linhas: o que estudou, o que mudou, o que mediu.

---

## Por onde começar (ordem sugerida)

Se estiver na primeira rodada, siga esta ordem — ela vai do que mais se sente para o que
menos se sente:

1. **A sensação de andar** — aceleração, parada, virar, pular, peso (`physics3d.js`, `main.js`).
   É o que a pessoa faz 90% do tempo.
2. **A câmera** — o que ela faz ao chegar perto de parede, ao correr, ao olhar para cima.
3. **Marcos para se orientar** — dá para saber onde você está sem olhar o mapa? (`docs/CIDADE.md`)
4. **Entrar nos minigames** — o convite é claro? Chegar perto é gostoso?
5. **O HUD** — **tirar** elemento, não acrescentar (`docs/HUD.md`).
6. **Vida no mundo** — som ambiente por área, gente passando, luz mudando.

## O que **não** fazer nesta automação

- Não copiar arte, modelo, textura, som ou código de jogo comercial. Estude o **princípio**,
  faça a sua versão. Isso não é só ética, é o único caminho legal.
  Modelo novo só de fonte CC0 / domínio público (ver `FONTES-MODELOS-3D.md`).
- Não acrescentar minigame novo (já são 9).
- Não trocar o estilo visual definido em `AGENTS.md`.
- Não encher a tela de HUD "porque o GTA tem".
- Não deixar uma rodada sem medir desempenho.
