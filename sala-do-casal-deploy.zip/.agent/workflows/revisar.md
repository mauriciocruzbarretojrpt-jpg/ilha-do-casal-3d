---
description: Revisa o jogo inteiro, encontra bugs de verdade e corrige um de cada vez
---

# /revisar — passada de revisão

Uma rodada de revisão da Ilha do Casal. O objetivo **não** é mexer em muita coisa: é
encontrar problemas reais, consertar os mais graves com segurança e deixar registrado
o que ficou.

> ⚠️ **A regra mais importante:** um bug só existe depois de **reproduzido**.
> Se você não conseguiu ver o problema acontecer, ele vai para a lista de "suspeitas",
> não para a lista de correções. Nunca "conserte" o que você não viu quebrado.

Antes de começar, **leia `docs/DIARIO.md`** — o que já foi consertado, o que ficou sem
verificar e quais suspeitas estavam abertas.

---

## 1. Abrir o jogo e deixar rodando

1. `npm install` (se precisar) e `npm start`.
2. Abra `http://localhost:3000`.
3. Confira o **console do navegador** e o terminal do servidor. Anote todo erro e aviso —
   inclusive os de `.glb` que não carregou e de textura faltando.
4. Deixe aberto — você vai usar isso o tempo todo.

Se o painel do navegador estiver escondido, as animações congelam (o navegador limita o
`requestAnimationFrame`). **Traga a janela para a frente antes de julgar qualquer coisa
que se mexe.** Se não for possível, diga isso no relatório em vez de concluir errado.

## 2. Passar o jogo inteiro

Entre numa sala, ligue o robô (`btn-join-bot`) e percorra tudo. Em **cada** item, olhe de verdade:

**Mundo**
- [ ] Anda, corre e pula nas 4 direções; o boneco olha para onde anda
- [ ] A câmera gira e dá zoom; não atravessa parede, prédio nem morro
- [ ] Não dá para atravessar o cenário nem cair fora do mapa (`physics3d.js`)
- [ ] Maria e Mauricio aparecem com textura e tamanho certos (`characters.js`)
- [ ] Os props carregam todos (`propLoader.js`); nenhum fica branco ou flutuando
- [ ] Chat, balões, emotes e o seletor de clima funcionam
- [ ] FPS estável andando pelo mapa inteiro (**meça, não ache**)

**Os 9 minigames** (`public/js/games/`) — entre em cada um e jogue uma rodada até o fim:

| Arquivo | Jogo |
|---|---|
| `tennis3d.js` | tênis |
| `kart3d.js` | corrida |
| `pool3d.js` | sinuca |
| `atelier3d.js` | desenhe e adivinhe |
| `stage3d.js` | palco |
| `memory3d.js` | memória |
| `connect4_3d.js` | ligue 4 |
| `tictactoe3d.js` | jogo da velha |
| `rps3d.js` | pedra-papel-tesoura |

- [ ] Começa, dá para jogar, termina e dá para voltar ao mundo
- [ ] O placar conta certo e o servidor concorda com a tela
- [ ] O robô (`src/aiPartner.js`) joga sozinho e não trava
- [ ] A tela de fim de jogo aparece e o "jogar de novo" funciona

**Celular** — repita o essencial com a janela em 390x844 e em 844x390:
- [ ] Nada fora da tela nem sobreposto; a área segura do iPhone é respeitada
- [ ] Joystick, botão de pulo, botão de ação e os controles de cada jogo respondem ao toque
- [ ] Dá para ler os textos
- [ ] Nada essencial embaixo do dedo do joystick

## 3. Separar o que achou

Monte três listas:

| Lista | O que entra | O que fazer |
|---|---|---|
| **Quebrado** | erro no console, jogo trava, não dá para terminar, elemento fora da tela, modelo que não carrega | corrigir agora |
| **Errado** | funciona mas está visivelmente torto, invertido, feio ou confuso | corrigir se for rápido e seguro |
| **Suspeita** | você acha que tem problema mas não conseguiu reproduzir | **só anotar**, não mexer |

Ordene por: atrapalha jogar > aparece sempre > é rápido de arrumar.

## 4. Corrigir — um de cada vez

Para **cada** correção, nesta ordem:

1. **Reproduza** e descreva em uma linha o que você viu ("ao entrar na sinuca pelo celular,
   a barra de força fica fora da tela").
2. **Ache a causa de verdade.** Não ponha remendo em cima do sintoma.
3. **Faça a menor mudança possível** que resolve.
4. **Verifique o conserto** no navegador, do mesmo jeito que reproduziu.
5. **Verifique que não quebrou o vizinho**: teste de novo a tela que você mexeu e uma
   adjacente. Mexeu em `world3d.js` ou `physics3d.js`? Ande pelo mapa e entre em 2 minigames.
6. Só então vá para a próxima.

**Pare e pergunte** em vez de seguir, se:
- a correção exige mudar a estrutura do jogo ou o protocolo de Socket.IO
- você precisaria desfazer uma decisão de design que está em `AGENTS.md` ou nos `docs/`
- você tentou duas vezes e não resolveu

## 5. Fechar a passada

Acrescente uma entrada **no topo** de `docs/DIARIO.md`:

```markdown
## <data> — revisão
**Corrigido:** <um por linha, com o que você viu antes e depois, e o arquivo>
**Não verificado:** <o que não deu para testar, e por quê>
**Suspeitas:** <não reproduzidas, para a próxima>
**Desempenho:** FPS no PC __ / no celular __ · draw calls __
```

No fim, responda em **até 10 linhas**: o que estava quebrado, o que você consertou,
o que não conseguiu verificar. Sem enfeite.

---

## O que **não** fazer nesta automação

- Não refatorar código que funciona
- Não adicionar funcionalidade nova (isso é o `/aprimorar`)
- Não trocar biblioteca nem dependência
- Não mexer na estética definida em `AGENTS.md`
- Não baixar modelo nem textura nova
- Não apagar arquivo sem perguntar
- Não dizer "corrigido" sobre algo que você não viu funcionando
