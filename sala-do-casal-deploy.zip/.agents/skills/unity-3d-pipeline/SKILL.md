---
name: unity-3d-pipeline
description: >-
  Guides Unity 3D project architecture, Humanoid Avatar Mecanim retargeting,
  2D Blend Tree locomotion controllers, Foot IK, Cinemachine 3rd-person cameras,
  and batchmode CLI automation. Use when building, migrating, or automating
  3D games and character animation pipelines in Unity.
---

# Unity 3D & Humanoid Animation Pipeline

Use this skill when authoring Unity C# gameplay scripts, configuring Mecanim Humanoid rigs for GLB/FBX characters (such as `maria.glb` and `mauricio.glb`), or running Unity Editor batchmode automation.

## 1. CLI Batchmode Execution (Windows)

When Unity Hub / Unity Editor is installed (`C:\Program Files\Unity\Hub\Editor\<version>\Editor\Unity.exe`):

```powershell
& "C:\Program Files\Unity\Hub\Editor\<version>\Editor\Unity.exe" -batchmode -nographics -quit -projectPath "<project>" -executeMethod BuildTools.Run -logFile unity_batch.log
```

If Unity is not installed locally, check the Antigravity Marketplace for the official **Unity** plugin (`antigravity-plugins-partners/plugin/unity`) or use `blender-3d-pipeline` to bake Humanoid MoCap directly into `.glb` assets for WebGL/Three.js.

## 2. Humanoid Mecanim Setup for Mixamo / AI-Rigged Characters

1. Import `.fbx` or `.glb` (via `com.unity.cloud.gltfast` or Blender FBX conversion).
2. In `ModelImporter`:
   - Set `animationType = ModelImporterAnimationType.Human`.
   - Click **Configure Avatar** -> verify `Hips`, `Spine`, `Chest`, `UpperChest`, `Neck`, `Head`, shoulders, arms, legs, and all 15 finger bones per hand map green.
   - Click **Enforce T-Pose** in Avatar Configuration so A-pose meshes normalize cleanly into Unity Muscle Space!
3. Build an `AnimatorController` with:
   - **Base Layer**: 1D or 2D Freeform Cartesian Blend Tree (`Speed` parameter `0 -> 2.0 -> 5.5` blending `Idle`, `Walk`, `Run` MoCap clips with `Foot IK` enabled on the state!).
   - **UpperBody Override / Additive Layer** (`AvatarMask` from `Spine1` upward): plays `Wave`, `Swing`, `Paint`, or `RPS` clips while legs continue walking or idling seamlessly.
   - **OnAnimatorIK(int layerIndex)**: raycast downward from `AvatarIKGoal.LeftFoot` and `RightFoot` to pin feet onto stairs, bridges, and slopes without foot-skating.
