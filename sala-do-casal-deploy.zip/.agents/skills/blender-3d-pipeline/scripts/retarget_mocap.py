# Headless Blender 5.2 Optical Motion-Capture Retargeting Pipeline
# Retargets real studio MoCap GLBs (HVGirl, Xbot, Michelle, Soldier) onto A-pose GLB characters
# (maria.glb & mauricio.glb) using Coordinate-System-Independent Orthonormal Joint Triads!
#
# Usage:
# blender -b --factory-startup --python retarget_mocap.py -- <raw_char.glb> <out_char.glb> <gender:female|male> <mocap_dir>

import bpy
import sys
import os
import math
from mathutils import Vector, Matrix, Quaternion, Euler

argv = sys.argv[sys.argv.index('--') + 1:]
RAW_GLB = argv[0]
OUT_GLB = argv[1]
GENDER = argv[2]  # 'female' or 'male'
MOCAP_DIR = argv[3]

def log(msg):
    print(f"[MoCap-Retarget] {msg}", flush=True)

def safe_norm(v, fallback=Vector((0, 0, 1))):
    length = v.length
    if length < 1e-6:
        return fallback.copy()
    return v / length

def make_triad(primary_dir, hint_sec):
    """Builds a right-handed 3x3 rotation matrix whose col0=X(sec), col1=Y(primary), col2=Z."""
    y = safe_norm(primary_dir, Vector((0, 0, 1)))
    # Orthogonalize hint_sec against y
    sec = hint_sec - y * hint_sec.dot(y)
    if sec.length < 1e-5:
        alt = Vector((1, 0, 0)) if abs(y.x) < 0.85 else Vector((0, 1, 0))
        sec = alt - y * alt.dot(y)
    x = safe_norm(sec, Vector((1, 0, 0)))
    z = safe_norm(x.cross(y), Vector((0, 0, 1)))
    x = safe_norm(y.cross(z), Vector((1, 0, 0)))
    return Matrix((
        (x.x, y.x, z.x),
        (x.y, y.y, z.y),
        (x.z, y.z, z.z),
    ))

# Core humanoid bones we retarget from 3D joint positions
CHAIN_SEGMENTS = [
    # (bone_name, start_joint, end_joint, triad_mode)
    ('Hips',          'Hips',          'Spine',         'pelvis'),
    ('Spine',         'Spine',         'Spine1',        'torso'),
    ('Spine1',        'Spine1',        'Spine2',        'torso'),
    ('Spine2',        'Spine2',        'Neck',          'chest'),
    ('Neck',          'Neck',          'Head',          'chest'),
    ('Head',          'Head',          'HeadTop',       'head'),
    ('LeftShoulder',  'LeftShoulder',  'LeftArm',       'shoulder_l'),
    ('RightShoulder', 'RightShoulder', 'RightArm',      'shoulder_r'),
    ('LeftUpLeg',     'LeftUpLeg',     'LeftLeg',       'thigh_l'),
    ('LeftLeg',       'LeftLeg',       'LeftFoot',      'shin_l'),
    ('LeftFoot',      'LeftFoot',      'LeftToeBase',   'foot_l'),
    ('RightUpLeg',    'RightUpLeg',    'RightLeg',      'thigh_r'),
    ('RightLeg',      'RightLeg',      'RightFoot',     'shin_r'),
    ('RightFoot',     'RightFoot',     'RightToeBase',  'foot_r'),
    ('LeftArm',       'LeftArm',       'LeftForeArm',   'uarm_l'),
    ('LeftForeArm',   'LeftForeArm',   'LeftHand',      'farm_l'),
    ('LeftHand',      'LeftHand',      'LeftHandMid',   'hand_l'),
    ('RightArm',      'RightArm',      'RightForeArm',  'uarm_r'),
    ('RightForeArm',  'RightForeArm',  'RightHand',     'farm_r'),
    ('RightHand',     'RightHand',     'RightHandMid',  'hand_r'),
]

FINGER_NAMES = [
    f"{side}Hand{fg}{idx}"
    for side in ('Left', 'Right')
    for fg in ('Thumb', 'Index', 'Middle', 'Ring', 'Pinky')
    for idx in (1, 2, 3)
]

def get_bone(arm, name):
    for prefix in ('', 'mixamorig:', 'mixamorig'):
        b = arm.pose.bones.get(prefix + name)
        if b is not None:
            return b
    return None

def extract_joint_positions(arm, is_rest=False, yaw_fix_mat=Matrix.Identity(3)):
    """Returns dict of world-space 3D joint positions (oriented so character faces -Y, +Z up, +X left)."""
    mw = arm.matrix_world
    pts = {}
    core_names = [
        'Hips', 'Spine', 'Spine1', 'Spine2', 'Neck', 'Head',
        'LeftShoulder', 'LeftArm', 'LeftForeArm', 'LeftHand',
        'RightShoulder', 'RightArm', 'RightForeArm', 'RightHand',
        'LeftUpLeg', 'LeftLeg', 'LeftFoot', 'LeftToeBase',
        'RightUpLeg', 'RightLeg', 'RightFoot', 'RightToeBase',
        'LeftHandIndex1', 'LeftHandMiddle1', 'LeftHandPinky1',
        'RightHandIndex1', 'RightHandMiddle1', 'RightHandPinky1',
        'HeadTop_End',
    ]
    for nm in core_names:
        pb = get_bone(arm, nm)
        if pb:
            local_pt = pb.bone.head_local if is_rest else pb.head
            pts[nm] = yaw_fix_mat @ (mw @ local_pt)

    # Virtual end effectors if HeadTop_End is absent (e.g. maria.glb / mauricio.glb)
    head_pb = get_bone(arm, 'Head')
    if 'HeadTop_End' in pts:
        pts['HeadTop'] = pts['HeadTop_End']
    elif head_pb:
        if is_rest:
            pts['HeadTop'] = yaw_fix_mat @ (mw @ head_pb.bone.tail_local)
        else:
            pts['HeadTop'] = yaw_fix_mat @ (mw @ head_pb.tail)

    # Hand mid-knuckle & palm vectors
    for side in ('Left', 'Right'):
        m1 = pts.get(f'{side}HandMiddle1')
        h0 = pts.get(f'{side}Hand')
        if m1 and h0:
            pts[f'{side}HandMid'] = m1
        elif h0:
            pb = get_bone(arm, f'{side}Hand')
            pts[f'{side}HandMid'] = yaw_fix_mat @ (mw @ (pb.bone.tail_local if is_rest else pb.tail))

    return pts

def compute_segment_triads(pts):
    """Computes anatomically consistent 3x3 world triads for every segment from 3D joint positions."""
    hip_lat = safe_norm(pts['LeftUpLeg'] - pts['RightUpLeg'], Vector((1, 0, 0)))
    sh_lat = safe_norm(pts['LeftShoulder'] - pts['RightShoulder'], Vector((1, 0, 0)))
    spine_up = safe_norm(pts['Spine2'] - pts['Hips'], Vector((0, 0, 1)))

    # Forward direction (-Y in Blender Z-up)
    pelvis_fwd = safe_norm(hip_lat.cross(spine_up), Vector((0, -1, 0)))
    chest_fwd = safe_norm(sh_lat.cross(spine_up), Vector((0, -1, 0)))

    triads = {}
    for bone_name, j_start, j_end, mode in CHAIN_SEGMENTS:
        if j_start not in pts or j_end not in pts:
            continue
        d = safe_norm(pts[j_end] - pts[j_start], Vector((0, 0, 1)))

        if mode == 'pelvis':
            hint = hip_lat
        elif mode == 'torso':
            hint = hip_lat.lerp(sh_lat, 0.5)
        elif mode in ('chest', 'head'):
            hint = sh_lat
        elif mode in ('shoulder_l', 'shoulder_r'):
            hint = spine_up
        elif mode in ('thigh_l', 'shin_l', 'foot_l', 'thigh_r', 'shin_r', 'foot_r'):
            side = 'Left' if mode.endswith('_l') else 'Right'
            d_thigh = safe_norm(pts[f'{side}Leg'] - pts[f'{side}UpLeg'], Vector((0, 0, -1)))
            d_shin = safe_norm(pts[f'{side}Foot'] - pts[f'{side}Leg'], Vector((0, 0, -1)))
            d_foot = safe_norm(pts[f'{side}ToeBase'] - pts[f'{side}Foot'], Vector((0, -1, 0)))
            # Lateral axis of leg: blend hip_lat with foot/knee plane normal for twist stability!
            knee_cross = d_shin.cross(d_thigh)  # Points +X (left) when knee bends backward (+Y)!
            foot_cross = d_foot.cross(d_shin)   # Points +X (left) because foot points -Y and shin points -Z!
            leg_lat = hip_lat * 0.35 + safe_norm(foot_cross, hip_lat) * 0.65
            if knee_cross.length > 0.12:
                leg_lat = safe_norm(leg_lat + safe_norm(knee_cross, hip_lat) * 0.5, hip_lat)
            hint = leg_lat
        elif mode in ('uarm_l', 'farm_l', 'uarm_r', 'farm_r'):
            side = 'Left' if mode.endswith('_l') else 'Right'
            i1 = pts.get(f'{side}HandIndex1')
            p1 = pts.get(f'{side}HandPinky1')
            d_ua = safe_norm(pts[f'{side}ForeArm'] - pts[f'{side}Arm'], Vector((1, 0, 0)))
            d_fa = safe_norm(pts[f'{side}Hand'] - pts[f'{side}ForeArm'], Vector((1, 0, 0)))
            elbow_cross = d_ua.cross(d_fa)
            # Combine elbow hinge axis + palm knuckle axis for natural forearm twist!
            knuckle = safe_norm(i1 - p1, chest_fwd) if (i1 and p1) else chest_fwd
            if elbow_cross.length > 0.18:
                # Ensure consistent sign with backward elbow pole
                hint = elbow_cross
            else:
                hint = knuckle if 'farm' in mode else chest_fwd
        elif mode in ('hand_l', 'hand_r'):
            side = 'Left' if mode.endswith('_l') else 'Right'
            i1 = pts.get(f'{side}HandIndex1')
            p1 = pts.get(f'{side}HandPinky1')
            hint = safe_norm(i1 - p1, chest_fwd) if (i1 and p1) else chest_fwd
        else:
            hint = hip_lat

        triads[bone_name] = make_triad(d, hint)
    return triads

def sample_mocap_clip(glb_path, action_name):
    """Loads a source MoCap GLB in a temporary scene, samples every frame's joint triads & hip motion."""
    tmp_scene = bpy.data.scenes.new("TmpMoCap")
    old_scene = bpy.context.window.scene
    bpy.context.window.scene = tmp_scene

    before_objs = set(bpy.data.objects)
    before_acts = set(bpy.data.actions)
    bpy.ops.import_scene.gltf(filepath=glb_path)
    new_objs = [o for o in bpy.data.objects if o not in before_objs]
    new_acts = [a for a in bpy.data.actions if a not in before_acts]

    src_arm = next(o for o in new_objs if o.type == 'ARMATURE')
    act = next((a for a in new_acts if a.name.lower() == action_name.lower()), None)
    if act is None:
        act = next((a for a in new_acts if action_name.lower() in a.name.lower()), new_acts[0])

    if not src_arm.animation_data:
        src_arm.animation_data_create()
    src_arm.animation_data.action = act

    f_start, f_end = int(round(act.frame_range[0])), int(round(act.frame_range[1]))

    # Robust anatomical facing detection: average (LeftUpLeg - RightUpLeg) x (Spine2 - Hips)
    # across frames so bent knees or heel-kicks NEVER flip Run/Dance by 180° or skew Walk!
    mw = src_arm.matrix_world
    l_hip_pb = get_bone(src_arm, 'LeftUpLeg')
    r_hip_pb = get_bone(src_arm, 'RightUpLeg')
    hips_src_pb = get_bone(src_arm, 'Hips')
    sp2_src_pb = get_bone(src_arm, 'Spine2')

    acc_fwd_xy = Vector((0.0, 0.0, 0.0))
    sample_step = max(1, (f_end - f_start + 1) // 12)
    for sf in range(f_start, f_end + 1, sample_step):
        tmp_scene.frame_set(sf)
        bpy.context.view_layer.update()
        lat = (mw @ l_hip_pb.head) - (mw @ r_hip_pb.head)
        upv = (mw @ sp2_src_pb.head) - (mw @ hips_src_pb.head)
        fwd3 = lat.cross(upv)
        fxy = Vector((fwd3.x, fwd3.y, 0.0))
        if fxy.length > 1e-5:
            acc_fwd_xy += fxy.normalized()

    # Target faces -Y (x=0, y=-1). Rotate XY by -atan2(fx, -fy) so fwd lands on (0, -1, 0)!
    # Check: if fwd_xy = (sin a, -cos a), atan2(sin a, cos a) = a, and R_z(-a) @ (sin a, -cos a) = (0, -1)!
    cur_yaw = -math.atan2(acc_fwd_xy.x, -acc_fwd_xy.y) if acc_fwd_xy.length > 1e-4 else 0.0
    yaw_fix = Euler((0, 0, cur_yaw), 'XYZ').to_matrix()

    tmp_scene.frame_set(f_start)
    bpy.context.view_layer.update()

    # Measure leg length for hip height scaling
    p0 = extract_joint_positions(src_arm, is_rest=False, yaw_fix_mat=yaw_fix)
    src_leg_len = (p0['LeftUpLeg'] - p0['LeftLeg']).length + (p0['LeftLeg'] - p0['LeftFoot']).length
    base_hip_xy = Vector((p0['Hips'].x, p0['Hips'].y))

    frames_data = []
    min_foot_z = 1e9
    raw_hip_z = []

    for f in range(f_start, f_end + 1):
        tmp_scene.frame_set(f)
        bpy.context.view_layer.update()
        pts = extract_joint_positions(src_arm, is_rest=False, yaw_fix_mat=yaw_fix)
        triads = compute_segment_triads(pts)
        # Track lowest toe/foot height across cycle to ground feet cleanly
        low_z = min(pts['LeftFoot'].z, pts['RightFoot'].z, pts['LeftToeBase'].z, pts['RightToeBase'].z)
        min_foot_z = min(min_foot_z, low_z)
        raw_hip_z.append(pts['Hips'].z)
        # Keep subtle lateral sway (X), remove forward root travel (Y) for in-place game locomotion!
        sway_x = pts['Hips'].x - base_hip_xy.x
        frames_data.append({
            'triads': triads,
            'sway_x': sway_x,
            'hip_z': pts['Hips'].z,
        })

    mean_hip_z = sum(raw_hip_z) / max(1, len(raw_hip_z))
    for fd in frames_data:
        fd['dh_z'] = fd['hip_z'] - mean_hip_z

    log(f"Sampled '{act.name}' from {os.path.basename(glb_path)} ({len(frames_data)} frames, leg={src_leg_len:.3f}m)")

    # Cleanup temporary objects
    bpy.context.window.scene = old_scene
    for o in new_objs:
        bpy.data.objects.remove(o, do_unlink=True)
    bpy.data.scenes.remove(tmp_scene)

    return {
        'frames': frames_data,
        'leg_len': max(0.01, src_leg_len),
    }

# ==================== 1. LOAD TARGET CHARACTER (MARIA OR MAURICIO) ====================

bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.context.scene.render.fps = 30
log(f"Importing target character: {RAW_GLB}")
bpy.ops.import_scene.gltf(filepath=RAW_GLB)

tgt_arm = next(o for o in bpy.data.objects if o.type == 'ARMATURE')
if not tgt_arm.animation_data:
    tgt_arm.animation_data_create()
tgt_arm.animation_data.action = None

# Reset pose to pure rest
for pb in tgt_arm.pose.bones:
    pb.rotation_mode = 'QUATERNION'
    pb.rotation_quaternion = Quaternion((1, 0, 0, 0))
    pb.location = Vector((0, 0, 0))
    pb.scale = Vector((1, 1, 1))
bpy.context.view_layer.update()

tgt_rest_pts = extract_joint_positions(tgt_arm, is_rest=True)
tgt_rest_triads = compute_segment_triads(tgt_rest_pts)
tgt_leg_len = (tgt_rest_pts['LeftUpLeg'] - tgt_rest_pts['LeftLeg']).length + (tgt_rest_pts['LeftLeg'] - tgt_rest_pts['LeftFoot']).length

mw_tgt3 = tgt_arm.matrix_world.to_3x3().normalized()
mw_tgt3_inv = mw_tgt3.inverted()

tgt_bone_rest_world3 = {}
for pb in tgt_arm.pose.bones:
    tgt_bone_rest_world3[pb.name] = (mw_tgt3 @ pb.bone.matrix_local.to_3x3()).normalized()

hips_pb = get_bone(tgt_arm, 'Hips')
hips_world_to_basis3 = (mw_tgt3 @ hips_pb.bone.matrix_local.to_3x3()).inverted()

def set_finger_curl_on_pose(curl_dict):
    """Applies natural relaxed or expressive finger curl in local bone X rotation."""
    for fname in FINGER_NAMES:
        pb = get_bone(tgt_arm, fname)
        if not pb:
            continue
        fg = 'Thumb' if 'Thumb' in fname else ('Index' if 'Index' in fname else ('Middle' if 'Middle' in fname else ('Ring' if 'Ring' in fname else 'Pinky')))
        c = curl_dict.get(fg, 0.24)
        idx = int(fname[-1])
        ang = c * (0.75 if idx == 1 else 1.0)
        pb.rotation_quaternion = Euler((ang, 0, 0), 'XYZ').to_quaternion()

def bake_retargeted_action(clip_name, sampled, finger_pose=None, seamless_loop=True):
    act = bpy.data.actions.new(name=clip_name)
    tgt_arm.animation_data.action = act
    scale_ratio = tgt_leg_len / sampled['leg_len']
    frames = sampled['frames']
    n_frames = len(frames)

    if finger_pose is None:
        finger_pose = {'Thumb': 0.18, 'Index': 0.24, 'Middle': 0.30, 'Ring': 0.36, 'Pinky': 0.42}

    for idx, fd in enumerate(frames):
        f_num = idx + 1
        bpy.context.scene.frame_set(f_num)

        # Reset pose
        for pb in tgt_arm.pose.bones:
            pb.rotation_quaternion = Quaternion((1, 0, 0, 0))
            pb.location = Vector((0, 0, 0))

        # Apply Hips bounce & lateral weight shift
        dw = Vector((fd['sway_x'] * scale_ratio, 0.0, fd['dh_z'] * scale_ratio))
        hips_pb.location = hips_world_to_basis3 @ dw
        hips_pb.keyframe_insert(data_path='location', frame=f_num)

        # Apply parent-to-child hierarchical bone rotations using Blender's exact convert_space!
        for bone_name, _, _, _ in CHAIN_SEGMENTS:
            pb = get_bone(tgt_arm, bone_name)
            if not pb or bone_name not in fd['triads'] or bone_name not in tgt_rest_triads:
                continue
            F_src = fd['triads'][bone_name]
            F_tgt = tgt_rest_triads[bone_name]
            R_delta_world = F_src @ F_tgt.transposed()
            desired_world3 = R_delta_world @ tgt_bone_rest_world3[pb.name]
            desired_pose3 = mw_tgt3_inv @ desired_world3

            # Update view layer matrices along hierarchy or compute directly from parent pose matrix!
            bpy.context.view_layer.update()
            pose_m4 = pb.matrix.copy()
            loc = pose_m4.to_translation()
            new_pose_m4 = desired_pose3.to_4x4()
            new_pose_m4.translation = loc

            local_m4 = tgt_arm.convert_space(pose_bone=pb, matrix=new_pose_m4, from_space='POSE', to_space='LOCAL')
            pb.rotation_quaternion = local_m4.to_quaternion()
            pb.keyframe_insert(data_path='rotation_quaternion', frame=f_num)

        set_finger_curl_on_pose(finger_pose)
        for fname in FINGER_NAMES:
            fpb = get_bone(tgt_arm, fname)
            if fpb:
                fpb.keyframe_insert(data_path='rotation_quaternion', frame=f_num)

    # Ensure quaternion continuity (antipodal sign flip prevention so slerp never spins 360°!)
    fix_quaternion_signs(act)
    log(f"Baked MoCap clip '{clip_name}' ({n_frames} frames)")
    return act

def fix_quaternion_signs(action):
    # Group quaternion fcurves by bone data_path
    by_path = {}
    # Blender 5.x layered actions / channelbags support + classic action.fcurves fallback
    fcurves = getattr(action, 'fcurves', None)
    if fcurves is None and hasattr(action, 'layers') and len(action.layers) > 0:
        strip = action.layers[0].strips[0]
        fcurves = strip.channelbags[0].fcurves
    if not fcurves:
        return

    for fc in fcurves:
        if fc.data_path.endswith('rotation_quaternion'):
            by_path.setdefault(fc.data_path, {})[fc.array_index] = fc

    for path, chans in by_path.items():
        if len(chans) != 4:
            continue
        n_keys = len(chans[0].keyframe_points)
        prev_q = None
        for k in range(n_keys):
            q = Quaternion((
                chans[0].keyframe_points[k].co[1],
                chans[1].keyframe_points[k].co[1],
                chans[2].keyframe_points[k].co[1],
                chans[3].keyframe_points[k].co[1],
            ))
            if prev_q is not None and prev_q.dot(q) < 0:
                q = -q
                for ci in range(4):
                    chans[ci].keyframe_points[k].co[1] = q[ci]
            prev_q = q
        for fc in chans.values():
            fc.update()

def create_layered_action_from_idle(name, idle_sampled, total_frames, pose_modifier_fn):
    """Creates a smooth organic action (Wave, Jump, Sit, Swing) layered directly over real MoCap Idle!"""
    act = bpy.data.actions.new(name=name)
    tgt_arm.animation_data.action = act
    idle_frames = idle_sampled['frames']
    scale_ratio = tgt_leg_len / idle_sampled['leg_len']

    for idx in range(total_frames):
        f_num = idx + 1
        u = idx / max(1, total_frames - 1)
        src_fd = idle_frames[idx % len(idle_frames)]
        bpy.context.scene.frame_set(f_num)

        for pb in tgt_arm.pose.bones:
            pb.rotation_quaternion = Quaternion((1, 0, 0, 0))
            pb.location = Vector((0, 0, 0))

        dw = Vector((src_fd['sway_x'] * scale_ratio, 0.0, src_fd['dh_z'] * scale_ratio))
        hips_pb.location = hips_world_to_basis3 @ dw

        # First apply living MoCap Idle posture
        for bone_name, _, _, _ in CHAIN_SEGMENTS:
            pb = get_bone(tgt_arm, bone_name)
            if not pb or bone_name not in src_fd['triads'] or bone_name not in tgt_rest_triads:
                continue
            R_delta_world = src_fd['triads'][bone_name] @ tgt_rest_triads[bone_name].transposed()
            desired_world3 = R_delta_world @ tgt_bone_rest_world3[pb.name]
            desired_pose3 = mw_tgt3_inv @ desired_world3
            bpy.context.view_layer.update()
            pose_m4 = pb.matrix.copy()
            new_pose_m4 = desired_pose3.to_4x4()
            new_pose_m4.translation = pose_m4.to_translation()
            local_m4 = tgt_arm.convert_space(pose_bone=pb, matrix=new_pose_m4, from_space='POSE', to_space='LOCAL')
            pb.rotation_quaternion = local_m4.to_quaternion()

        set_finger_curl_on_pose({'Thumb': 0.18, 'Index': 0.24, 'Middle': 0.30, 'Ring': 0.36, 'Pinky': 0.42})

        # Layer custom gameplay motion in world space on top!
        pose_modifier_fn(u, hips_pb, scale_ratio)

        hips_pb.keyframe_insert(data_path='location', frame=f_num)
        for pb in tgt_arm.pose.bones:
            pb.keyframe_insert(data_path='rotation_quaternion', frame=f_num)

    fix_quaternion_signs(act)
    log(f"Baked layered MoCap action '{name}' ({total_frames} frames)")
    return act

def rotate_bone_world(bone_name, rx, ry, rz):
    """Rotates a posed bone in Blender world space (X=left, Y=-fwd, Z=up) cleanly."""
    pb = get_bone(tgt_arm, bone_name)
    if not pb:
        return
    bpy.context.view_layer.update()
    R_w = Euler((rx, ry, rz), 'XYZ').to_matrix()
    cur_world3 = mw_tgt3 @ pb.matrix.to_3x3()
    new_pose3 = mw_tgt3_inv @ (R_w @ cur_world3)
    new_m4 = new_pose3.to_4x4()
    new_m4.translation = pb.matrix.to_translation()
    local_m4 = tgt_arm.convert_space(pose_bone=pb, matrix=new_m4, from_space='POSE', to_space='LOCAL')
    pb.rotation_quaternion = local_m4.to_quaternion()

def set_bone_world_dir(bone_name, target_dir, hint_sec):
    """Points a bone along target_dir in Blender world space (X=left, -Y=forward, +Z=up)."""
    pb = get_bone(tgt_arm, bone_name)
    if not pb or bone_name not in tgt_rest_triads:
        return
    bpy.context.view_layer.update()
    F_des = make_triad(target_dir, hint_sec)
    R_delta = F_des @ tgt_rest_triads[bone_name].transposed()
    desired_world3 = R_delta @ tgt_bone_rest_world3[pb.name]
    new_m4 = (mw_tgt3_inv @ desired_world3).to_4x4()
    new_m4.translation = pb.matrix.to_translation()
    local_m4 = tgt_arm.convert_space(pose_bone=pb, matrix=new_m4, from_space='POSE', to_space='LOCAL')
    pb.rotation_quaternion = local_m4.to_quaternion()

# ==================== 2. SAMPLE REAL OPTICAL MOCAP CLIPS ====================

hv_path = os.path.join(MOCAP_DIR, 'HVGirl.glb')
xbot_path = os.path.join(MOCAP_DIR, 'Xbot.glb')
michelle_path = os.path.join(MOCAP_DIR, 'Michelle.glb')

if GENDER == 'female':
    idle_mc = sample_mocap_clip(hv_path, 'Idle')
    walk_mc = sample_mocap_clip(hv_path, 'Walking')
    walk_back_mc = sample_mocap_clip(hv_path, 'WalkingBack')
    run_mc = sample_mocap_clip(xbot_path, 'run')
    dance_mc = sample_mocap_clip(hv_path, 'Samba')
else:
    idle_mc = sample_mocap_clip(xbot_path, 'idle')
    walk_mc = sample_mocap_clip(xbot_path, 'walk')
    walk_back_mc = {
        'frames': list(reversed(walk_mc['frames'])),
        'leg_len': walk_mc['leg_len'],
    }
    run_mc = sample_mocap_clip(xbot_path, 'run')
    dance_mc = sample_mocap_clip(michelle_path, 'SambaDance')

baked_actions = []
baked_actions.append(bake_retargeted_action('Idle', idle_mc))
baked_actions.append(bake_retargeted_action('Walk', walk_mc))
baked_actions.append(bake_retargeted_action('WalkBack', walk_back_mc))
baked_actions.append(bake_retargeted_action('Run', run_mc, {'Thumb': 0.55, 'Index': 0.9, 'Middle': 0.95, 'Ring': 1.0, 'Pinky': 1.05}))
baked_actions.append(bake_retargeted_action('Dance', dance_mc, {'Thumb': 0.12, 'Index': 0.15, 'Middle': 0.2, 'Ring': 0.25, 'Pinky': 0.3}))

# Wave: Natural friendly greeting over living MoCap Idle!
def wave_mod(u, h_pb, _sr):
    # Smooth envelope (seamless loop!)
    w = math.sin(u * math.pi * 4.0)
    rotate_bone_world('Spine2', 0.0, -0.05, 0.06)
    rotate_bone_world('Head', 0.04, 0.04 * w, 0.05)
    rotate_bone_world('RightShoulder', 0.0, -0.18, 0.0)
    # Right arm raised diagonally out (-X) and slightly forward (-Y) and up (+Z)
    set_bone_world_dir('RightArm', Vector((-0.78, -0.28, 0.42)), Vector((0, -1, 0)))
    set_bone_world_dir('RightForeArm', Vector((-0.22 + 0.34 * w, -0.25, 0.92)), Vector((0, -1, 0)))
    set_bone_world_dir('RightHand', Vector((-0.18 + 0.42 * w, -0.22, 0.94)), Vector((-1, 0, 0)))
    for fg in ('Thumb', 'Index', 'Middle', 'Ring', 'Pinky'):
        for idx in (1, 2, 3):
            fpb = get_bone(tgt_arm, f'RightHand{fg}{idx}')
            if fpb:
                fpb.rotation_quaternion = Euler((0.04, 0, 0), 'XYZ').to_quaternion()

baked_actions.append(create_layered_action_from_idle('Wave', idle_mc, 46, wave_mod))

# Jump: Anticipation -> Launch -> Airborne Tuck -> Reach!
def jump_mod(u, h_pb, _sr):
    arc = math.sin(u * math.pi)
    rotate_bone_world('Spine1', -0.12 * arc, 0, 0)
    set_bone_world_dir('LeftUpLeg', Vector((0.08, -0.68 * arc, -0.75)), Vector((1, 0, 0)))
    set_bone_world_dir('LeftLeg', Vector((0.05, 0.72 * arc, -0.78)), Vector((1, 0, 0)))
    set_bone_world_dir('RightUpLeg', Vector((-0.08, -0.52 * arc, -0.82)), Vector((1, 0, 0)))
    set_bone_world_dir('RightLeg', Vector((-0.05, 0.58 * arc, -0.84)), Vector((1, 0, 0)))
    set_bone_world_dir('LeftArm', Vector((0.75, -0.32 * arc, -0.35 + 0.55 * arc)), Vector((0, -1, 0)))
    set_bone_world_dir('RightArm', Vector((-0.75, -0.32 * arc, -0.35 + 0.55 * arc)), Vector((0, -1, 0)))

baked_actions.append(create_layered_action_from_idle('Jump', idle_mc, 26, jump_mod))

# Sit: Living seated idle (keeps real MoCap upper-body breathing & head micro-motion!)
def sit_mod(u, h_pb, _sr):
    set_bone_world_dir('LeftUpLeg', Vector((0.12, -0.96, 0.05)), Vector((1, 0, 0)))
    set_bone_world_dir('LeftLeg', Vector((0.02, -0.06, -0.99)), Vector((1, 0, 0)))
    set_bone_world_dir('LeftFoot', Vector((0.02, -0.95, -0.25)), Vector((1, 0, 0)))
    set_bone_world_dir('RightUpLeg', Vector((-0.12, -0.96, 0.05)), Vector((1, 0, 0)))
    set_bone_world_dir('RightLeg', Vector((-0.02, -0.06, -0.99)), Vector((1, 0, 0)))
    set_bone_world_dir('RightFoot', Vector((-0.02, -0.95, -0.25)), Vector((1, 0, 0)))
    set_bone_world_dir('LeftArm', Vector((0.35, -0.35, -0.85)), Vector((0, -1, 0)))
    set_bone_world_dir('LeftForeArm', Vector((0.05, -0.85, -0.35)), Vector((0, -1, 0)))
    set_bone_world_dir('RightArm', Vector((-0.35, -0.35, -0.85)), Vector((0, -1, 0)))
    set_bone_world_dir('RightForeArm', Vector((-0.05, -0.85, -0.35)), Vector((0, -1, 0)))

baked_actions.append(create_layered_action_from_idle('Sit', idle_mc, 60, sit_mod))

# ==================== 3. PUSH ALL ACTIONS TO NLA TRACKS & EXPORT GLB ====================

tgt_arm.animation_data.action = None
for act in baked_actions:
    track = tgt_arm.animation_data.nla_tracks.new()
    track.name = act.name
    strip = track.strips.new(act.name, 1, act)
    strip.name = act.name
    track.mute = False

os.makedirs(os.path.dirname(os.path.abspath(OUT_GLB)), exist_ok=True)
bpy.ops.export_scene.gltf(
    filepath=OUT_GLB,
    export_format='GLB',
    export_skins=True,
    export_yup=True,
    export_animations=True,
    export_animation_mode='NLA_TRACKS',
    export_optimize_animation_size=True,
)
log(f"SUCCESS! Exported {OUT_GLB} ({os.path.getsize(OUT_GLB)/1048576:.2f} MB) with {len(baked_actions)} embedded MoCap clips!")
