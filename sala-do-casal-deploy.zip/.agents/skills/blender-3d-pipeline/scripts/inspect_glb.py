# Inspects bone hierarchy, rest directions, materials, and animations of a GLB/FBX in Blender 5.2
import bpy, sys

argv = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
if not argv:
    print("Usage: blender -b --factory-startup --python inspect_glb.py -- <file.glb>")
    sys.exit(1)

bpy.ops.wm.read_factory_settings(use_empty=True)
path = argv[0]
if path.lower().endswith('.fbx'):
    bpy.ops.import_scene.fbx(filepath=path)
else:
    bpy.ops.import_scene.gltf(filepath=path)

print("=== OBJECTS IN", path, "===")
for o in bpy.data.objects:
    print(f" - {o.name} ({o.type}) scale={tuple(round(x,4) for x in o.scale)} rot={tuple(round(x,4) for x in o.rotation_euler)}")

for arm in [o for o in bpy.data.objects if o.type == 'ARMATURE']:
    print(f"=== ARMATURE {arm.name}: {len(arm.data.bones)} bones ===")
    for bname in ['Hips', 'Spine', 'Head', 'LeftArm', 'LeftForeArm', 'LeftHand', 'LeftUpLeg', 'LeftLeg', 'LeftFoot',
                  'mixamorig:Hips', 'mixamorig:LeftArm', 'mixamorig:LeftForeArm', 'mixamorig:LeftUpLeg']:
        b = arm.data.bones.get(bname)
        if b:
            y_dir = (arm.matrix_world.to_3x3() @ b.matrix_local.to_3x3() @ bpy.app.driver_namespace.get('V', b.y_axis if hasattr(b, 'y_axis') else b.vector))
            print(f"   Bone {b.name}: head={tuple(round(x,3) for x in (arm.matrix_world @ b.head_local))} tail={tuple(round(x,3) for x in (arm.matrix_world @ b.tail_local))}")

print("=== ACTIONS ===", len(bpy.data.actions))
for act in bpy.data.actions:
    fr = act.frame_range
    print(f" - Action '{act.name}': frames {fr[0]:.1f}..{fr[1]:.1f}")
