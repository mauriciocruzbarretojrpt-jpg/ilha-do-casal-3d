---
name: blender-3d-pipeline
description: >-
  Automates headless Blender 5.2 (bpy) workflows for inspecting GLB/FBX armatures,
  retargeting optical motion-capture animations across different rest poses (e.g.
  T-Pose Mixamo to A-Pose characters), authoring Bezier keyframe NLA actions,
  decimating meshes, and exporting game-ready GLB files with embedded animations.
  Use when creating, fixing, retargeting, or optimizing 3D models and animations.
---

# Blender 5.2 Headless 3D & Animation Pipeline

This skill enables Antigravity to drive **Blender 5.2** in background/headless mode (`-b --factory-startup`) via Python (`bpy` and `mathutils`) for studio-grade skeletal animation retargeting and GLB asset production.

## Binary Path (Windows)

```powershell
& "C:\Program Files\Blender Foundation\Blender 5.2\blender.exe" -b --factory-startup --python <script.py> -- <args...>
```

Always pass `--factory-startup` so user add-ons do not alter import/export behavior, and separate script arguments after `--`.

## Standard Procedures

### 1. Inspect Armature, Rest Pose & Embedded Actions
Before retargeting or editing any `.glb` or `.fbx`, inspect its bone names, rest-pose matrices, scale, and existing actions:
- Run [inspect_glb.py](./scripts/inspect_glb.py):
  ```powershell
  & "C:\Program Files\Blender Foundation\Blender 5.2\blender.exe" -b --factory-startup --python .agents/skills/blender-3d-pipeline/scripts/inspect_glb.py -- public/models/maria.glb
  ```

### 2. Retarget Motion-Capture (T-Pose <-> A-Pose Safe)
Naive quaternion copying fails when the source MoCap rig is in T-Pose (`Xbot.glb` / Mixamo) and the target character is in A-Pose (`maria.glb` / `mauricio.glb`). Always retarget in **Armature World-Rotation Space with Rest-Alignment**:

For each mapped bone $b$:
1. Let $R_{\text{src,rest}}$ and $R_{\text{tgt,rest}}$ be `bone.matrix_local.to_3x3()` on the source and target armatures (after baking/normalizing armature object transforms).
2. When both rigs follow the Mixamo bone-axis convention (local $+Y$ along bone from head to tail, consistent roll), a posed source bone with armature-space orientation $P_{\text{src}}(f)$ corresponds on the target bone to:
   $$P_{\text{tgt}}(f) = P_{\text{src}}(f)$$
   (for limbs whose absolute world-space pose should match the actor, such as arms hanging at the sides in `Idle`/`Walk`/`Run`), **or** for spine/head subtle posture preservation:
   $$P_{\text{tgt}}(f) = P_{\text{src}}(f) \cdot R_{\text{src,rest}}^{-1} \cdot R_{\text{tgt,rest}}$$
3. Convert $P_{\text{tgt}}(f)$ back to target `pose_bone.rotation_quaternion` (basis space) using Blender's `tgt_arm.convert_space(pose_bone=pb, matrix=mat4, from_space='POSE', to_space='LOCAL')`!
   Using `convert_space(..., 'POSE', 'LOCAL')` guarantees 100% exact parent-chain & rest-pose handling in Blender 5.x without manual matrix inversion bugs.

- Run [retarget_mocap.py](./scripts/retarget_mocap.py) to bake all MoCap & custom NLA clips into a target `.glb`.

### 3. Exporting Multi-Clip GLB for Three.js / Unity
In Blender 5.x `bpy.ops.export_scene.gltf`:
- Push every finished `bpy.types.Action` into its own **muted/non-overlapping NLA Track** (`arm_obj.animation_data.nla_tracks.new()`), clear `animation_data.action = None`, and export with:
  ```python
  bpy.ops.export_scene.gltf(
      filepath=out_path,
      export_format='GLB',
      export_skins=True,
      export_yup=True,
      export_animations=True,
      export_animation_mode='NLA_TRACKS',
      export_nla_strips_merged_animation_name='Animation',
      export_optimize_animation_size=True,
  )
  ```
- Verify the exported `.glb` by running `inspect_glb.py` on the output file and confirming every clip name and duration appears in `json.animations`.
